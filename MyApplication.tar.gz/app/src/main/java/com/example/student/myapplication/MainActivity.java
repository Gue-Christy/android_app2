package com.example.student.myapplication;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Menu;

import android.widget.Button;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    //String strxx;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //v.init();


    }
    class myView extends View {
        private Paint paint;
        public myView(Context context) {
            super(context);
            init();
        }
        private void init() {
            paint = new Paint();
            paint.setStyle(Paint.Style.FILL_AND_STROKE);
            invalidate(); //causes a canvas draw
        }
        protected void onDraw(Canvas canvas) {
            paint.setColor(Color.rgb(255,255,0));
            paint.setStyle(Paint.Style.FILL);
            int x = getMeasuredWidth();
            int y = getMeasuredHeight();
            canvas.drawRect(0, 0, x, y, paint);
            paint.setTextSize(100);
            paint.setColor(Color.BLACK);
            canvas.drawText("3350 Lab-11", 0, 70, paint);
        }
    }



/*    Button button = (Button) findViewById(R.id.button1);
    button.setOnClickListener(new View.OnClickListener() {
        public void onClick(View view) {
        });
  */
    public void Message() {

            myView v;
            v = new myView(this);
            setContentView(v);
    }

   /* public class Thx implements Runnable {
        @Override
        public void run(){
            try {
                URL url = new URL("http://cs.csubak.edu/~cguerrero/3350/potatoes.txt");
                BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
                StringBuilder total = new StringBuilder();
                String line;
                while ((line = in.readLine()) != null) {
                    total.append(line + " ");
                }
                strxx = total.toString();
                in.close();
            } catch (MalformedURLException e) {
            } catch (IOException e) {
            }
            return;
        }

    };
*/

}
